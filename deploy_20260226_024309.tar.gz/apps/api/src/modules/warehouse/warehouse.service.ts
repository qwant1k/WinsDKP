import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../../common/prisma/prisma.service';
import { PaginationDto, PaginatedResponse } from '../../common/dto/pagination.dto';
import { ItemRarity, WarehouseMovementType } from '@prisma/client';

@Injectable()
export class WarehouseService {
  constructor(private readonly prisma: PrismaService) {}

  async importFromExcel(
    clanId: string,
    rows: Array<{ name?: string; quantity?: number | string; source?: string }>,
    actorId: string,
  ) {
    if (!Array.isArray(rows) || rows.length === 0) {
      throw new BadRequestException('Import rows are required');
    }

    const aggregated = new Map<string, { name: string; source?: string; quantity: number; rarity: ItemRarity }>();

    for (const row of rows) {
      const name = (row.name || '').trim();
      if (!name) continue;

      const quantity = this.parsePositiveQuantity(row.quantity);
      if (!quantity) continue;

      const source = (row.source || '').trim() || undefined;
      const key = `${name.toLowerCase()}::${(source || '').toLowerCase()}`;
      const existing = aggregated.get(key);
      if (existing) {
        existing.quantity += quantity;
        continue;
      }

      aggregated.set(key, {
        name,
        source,
        quantity,
        rarity: this.detectRarityFromName(name),
      });
    }

    if (aggregated.size === 0) {
      throw new BadRequestException('No valid rows to import');
    }

    let created = 0;
    let updated = 0;

    await this.prisma.$transaction(async (tx) => {
      for (const item of aggregated.values()) {
        const existing = await tx.warehouseItem.findFirst({
          where: {
            clanId,
            deletedAt: null,
            name: item.name,
            source: item.source ?? null,
          },
        });

        if (existing) {
          await tx.warehouseItem.update({
            where: { id: existing.id },
            data: {
              quantity: { increment: item.quantity },
              rarity: item.rarity,
            },
          });

          await tx.warehouseItemMovement.create({
            data: {
              itemId: existing.id,
              type: WarehouseMovementType.INCOMING,
              quantity: item.quantity,
              reason: 'Excel import',
              performedBy: actorId,
            },
          });
          updated += 1;
          continue;
        }

        const createdItem = await tx.warehouseItem.create({
          data: {
            clanId,
            name: item.name,
            quantity: item.quantity,
            rarity: item.rarity,
            source: item.source,
          },
        });

        await tx.warehouseItemMovement.create({
          data: {
            itemId: createdItem.id,
            type: WarehouseMovementType.INCOMING,
            quantity: item.quantity,
            reason: 'Excel import',
            performedBy: actorId,
          },
        });

        created += 1;
      }
    });

    await this.prisma.auditLog.create({
      data: {
        actorId,
        action: 'warehouse.import.excel',
        entityType: 'warehouse',
        metadata: {
          clanId,
          sourceRows: rows.length,
          processedRows: aggregated.size,
          created,
          updated,
        },
      },
    });

    return {
      sourceRows: rows.length,
      processedRows: aggregated.size,
      created,
      updated,
    };
  }

  async findAll(clanId: string, query: PaginationDto) {
    const where = {
      clanId,
      deletedAt: null,
      ...(query.search ? { name: { contains: query.search, mode: 'insensitive' as const } } : {}),
    };
    const [items, total] = await Promise.all([
      this.prisma.warehouseItem.findMany({
        where,
        skip: query.skip,
        take: query.limit,
        orderBy: query.sortBy
          ? { [query.sortBy]: query.sortOrder || 'desc' }
          : { createdAt: 'desc' },
      }),
      this.prisma.warehouseItem.count({ where }),
    ]);
    return new PaginatedResponse(items, total, query.page, query.limit);
  }

  async findById(id: string) {
    const item = await this.prisma.warehouseItem.findUnique({
      where: { id },
      include: {
        movements: {
          orderBy: { createdAt: 'desc' },
          take: 50,
        },
      },
    });
    if (!item) throw new NotFoundException('Item not found');
    return item;
  }

  async create(clanId: string, data: {
    name: string;
    description?: string;
    quantity: number;
    rarity: ItemRarity;
    imageUrl?: string;
    dkpPrice?: number;
    source?: string;
  }, actorId: string) {
    const item = await this.prisma.warehouseItem.create({
      data: { clanId, ...data },
    });

    if (data.quantity > 0) {
      await this.prisma.warehouseItemMovement.create({
        data: {
          itemId: item.id,
          type: WarehouseMovementType.INCOMING,
          quantity: data.quantity,
          reason: 'Initial stock',
          performedBy: actorId,
        },
      });
    }

    await this.prisma.auditLog.create({
      data: {
        actorId,
        action: 'warehouse.item.created',
        entityType: 'warehouse_item',
        entityId: item.id,
        after: item,
      },
    });

    return item;
  }

  async update(id: string, data: {
    name?: string;
    description?: string;
    quantity?: number;
    rarity?: ItemRarity;
    imageUrl?: string;
    dkpPrice?: number;
    source?: string;
  }, actorId: string) {
    const before = await this.prisma.warehouseItem.findUnique({ where: { id } });
    if (!before) throw new NotFoundException('Item not found');

    let updated = await this.prisma.warehouseItem.update({
      where: { id },
      data,
    });

    if (updated.quantity <= 0 && !updated.deletedAt) {
      updated = await this.prisma.warehouseItem.update({
        where: { id },
        data: { deletedAt: new Date() },
      });
    }

    await this.prisma.auditLog.create({
      data: {
        actorId,
        action: 'warehouse.item.updated',
        entityType: 'warehouse_item',
        entityId: id,
        before,
        after: updated,
      },
    });

    return updated;
  }

  async addStock(id: string, quantity: number, reason: string, actorId: string) {
    if (quantity <= 0) throw new BadRequestException('Quantity must be positive');

    const item = await this.prisma.warehouseItem.findUnique({ where: { id } });
    if (!item) throw new NotFoundException('Item not found');

    await this.prisma.$transaction([
      this.prisma.warehouseItem.update({
        where: { id },
        data: { quantity: { increment: quantity } },
      }),
      this.prisma.warehouseItemMovement.create({
        data: {
          itemId: id,
          type: WarehouseMovementType.INCOMING,
          quantity,
          reason,
          performedBy: actorId,
        },
      }),
    ]);

    return this.findById(id);
  }

  async writeOff(id: string, quantity: number, reason: string, actorId: string) {
    if (quantity <= 0) throw new BadRequestException('Quantity must be positive');

    const item = await this.prisma.warehouseItem.findUnique({ where: { id } });
    if (!item) throw new NotFoundException('Item not found');
    if (item.quantity < quantity) throw new BadRequestException('Insufficient quantity');

    await this.prisma.$transaction(async (tx) => {
      const updated = await tx.warehouseItem.update({
        where: { id },
        data: { quantity: { decrement: quantity } },
      });

      await tx.warehouseItemMovement.create({
        data: {
          itemId: id,
          type: WarehouseMovementType.WRITE_OFF,
          quantity,
          reason,
          performedBy: actorId,
        },
      });

      if (updated.quantity <= 0) {
        await tx.warehouseItem.update({
          where: { id },
          data: { deletedAt: new Date() },
        });
      }
    });

    return this.findById(id);
  }

  async returnItem(id: string, quantity: number, reason: string, actorId: string) {
    if (quantity <= 0) throw new BadRequestException('Quantity must be positive');

    await this.prisma.$transaction([
      this.prisma.warehouseItem.update({
        where: { id },
        data: { quantity: { increment: quantity } },
      }),
      this.prisma.warehouseItemMovement.create({
        data: {
          itemId: id,
          type: WarehouseMovementType.RETURN,
          quantity,
          reason,
          performedBy: actorId,
        },
      }),
    ]);

    return this.findById(id);
  }

  async softDelete(id: string, actorId: string) {
    const item = await this.prisma.warehouseItem.findUnique({ where: { id } });
    if (!item) throw new NotFoundException('Item not found');

    await this.prisma.warehouseItem.update({
      where: { id },
      data: { deletedAt: new Date() },
    });

    await this.prisma.auditLog.create({
      data: {
        actorId,
        action: 'warehouse.item.deleted',
        entityType: 'warehouse_item',
        entityId: id,
        before: item,
      },
    });

    return { message: 'Item deleted' };
  }

  async softDeleteAll(clanId: string, actorId: string) {
    const items = await this.prisma.warehouseItem.findMany({
      where: { clanId, deletedAt: null },
      select: { id: true },
    });

    if (items.length === 0) {
      return { message: 'Warehouse already empty', deleted: 0 };
    }

    const now = new Date();
    const ids = items.map((i) => i.id);

    await this.prisma.$transaction([
      this.prisma.warehouseItem.updateMany({
        where: { id: { in: ids } },
        data: { deletedAt: now },
      }),
      this.prisma.auditLog.create({
        data: {
          actorId,
          action: 'warehouse.items.deleted_all',
          entityType: 'warehouse',
          metadata: {
            clanId,
            deletedCount: ids.length,
          },
        },
      }),
    ]);

    return { message: 'Warehouse cleared', deleted: ids.length };
  }

  async getMovements(itemId: string, query: PaginationDto) {
    const where = { itemId };
    const [movements, total] = await Promise.all([
      this.prisma.warehouseItemMovement.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: query.skip,
        take: query.limit,
      }),
      this.prisma.warehouseItemMovement.count({ where }),
    ]);
    return new PaginatedResponse(movements, total, query.page, query.limit);
  }

  private parsePositiveQuantity(quantity: number | string | undefined) {
    if (typeof quantity === 'number') {
      if (!Number.isFinite(quantity) || quantity <= 0) return 0;
      return Math.floor(quantity);
    }

    const normalized = String(quantity || '')
      .replace(',', '.')
      .replace(/[^\d.]/g, '');
    if (!normalized) return 0;

    const parsed = Number(normalized);
    if (!Number.isFinite(parsed) || parsed <= 0) return 0;
    return Math.floor(parsed);
  }

  private detectRarityFromName(name: string): ItemRarity {
    const normalized = name.toLowerCase();

    if (normalized.includes('высш')) return ItemRarity.LEGENDARY;
    if (normalized.includes('редк')) return ItemRarity.EPIC;
    if (normalized.includes('необ')) return ItemRarity.RARE;
    if (normalized.includes('ср.')) return ItemRarity.UNCOMMON;
    if (normalized.includes('ср ')) return ItemRarity.UNCOMMON;
    if (normalized.includes('сред')) return ItemRarity.UNCOMMON;
    if (normalized.includes('низк')) return ItemRarity.COMMON;

    return ItemRarity.COMMON;
  }
}
