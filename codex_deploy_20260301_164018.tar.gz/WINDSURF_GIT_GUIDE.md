# 🖥️ Работа с GitHub из Windsurf - Пошаговая инструкция

## Вариант 1: Через встроенный терминал (рекомендуется)

### Шаг 1: Открыть терминал в Windsurf

**Способ 1:** Меню
```
Terminal → New Terminal
```

**Способ 2:** Горячая клавиша
- Windows/Linux: `Ctrl + ` (обратная кавычка)
- macOS: `Cmd + ` (обратная кавычка)

**Способ 3:** Через Command Palette
```
Ctrl+Shift+P (Cmd+Shift+P на Mac) → "Terminal: Create New Terminal"
```

---

### Шаг 2: Проверка директории

Убедитесь, что вы в корне проекта:

```bash
# Проверка текущей директории
pwd

# Должно показать путь к вашему проекту, например:
# /Users/username/Projects/ymir-clan-hub
# или
# C:\Users\username\Projects\ymir-clan-hub
```

Если нет, перейдите в корень проекта:

```bash
cd /path/to/ymir-clan-hub
```

---

### Шаг 3: Инициализация Git (если еще не сделано)

```bash
# Инициализация Git-репозитория
git init

# Проверка, что Git инициализирован
git status
```

Должно показать:

```
On branch main  # или "On branch master"
No commits yet
Untracked files: ...
```

---

### Шаг 4: Добавление файлов

```bash
# Добавить ВСЕ файлы проекта
git add .

# Проверка статуса
git status
```

Должно показать зеленым все файлы, готовые к коммиту.

---

### Шаг 5: Создание коммита

```bash
# Создание коммита с описанием
git commit -m "Initial commit: Ymir Clan Hub production-ready"
```

Должно показать:

```
[main (root-commit) abc1234] Initial commit: Ymir Clan Hub production-ready
 XX files changed, XXXX insertions(+)
 create mode 100644 README.md
 ...
```

---

### Шаг 6: Создание репозитория на GitHub

**В браузере:**

1. Откройте https://github.com/new
2. Repository name: `ymir-clan-hub`
3. Description (опционально): `Production-ready MMORPG clan management system`
4. Private или Public — выберите на ваше усмотрение
5. **НЕ СТАВЬТЕ ГАЛОЧКИ:**
   - ❌ Add a README file
   - ❌ Add .gitignore
   - ❌ Choose a license
6. Нажмите **Create repository**

---

### Шаг 7: Связывание с GitHub

После создания репозитория GitHub покажет команды. Скопируйте URL репозитория.

**В терминале Windsurf:**

```bash
# Добавление remote (замените YOUR_USERNAME на ваш никнейм GitHub)
git remote add origin https://github.com/YOUR_USERNAME/ymir-clan-hub.git

# Проверка, что remote добавлен
git remote -v
```

Должно показать:

```
origin  https://github.com/YOUR_USERNAME/ymir-clan-hub.git (fetch)
origin  https://github.com/YOUR_USERNAME/ymir-clan-hub.git (push)
```

---

### Шаг 8: Переименование ветки в main (если нужно)

```bash
# Проверка текущей ветки
git branch

# Если показывает "master", переименуйте в "main":
git branch -M main
```

---

### Шаг 9: Отправка кода на GitHub

```bash
# Пуш кода в репозиторий
git push -u origin main
```

**Если попросит логин/пароль:**

GitHub больше не принимает пароли для HTTPS. Нужно использовать **Personal Access Token (PAT)**.

#### Создание Personal Access Token:

1. GitHub → https://github.com/settings/tokens
2. **Tokens (classic)** → **Generate new token (classic)**
3. Note: `Windsurf deployment token`
4. Expiration: `90 days` (или `No expiration` для постоянного)
5. Выберите scopes:
   - ✅ `repo` (полный доступ к репозиториям)
6. Нажмите **Generate token**
7. **ВАЖНО:** Скопируйте токен (он показывается только один раз!)

#### Использование токена:

```bash
# При запросе логина/пароля:
Username: ваш_никнейм_github
Password: вставьте_токен_вместо_пароля
```

---

### Шаг 10: Проверка на GitHub

Откройте в браузере:

```
https://github.com/YOUR_USERNAME/ymir-clan-hub
```

Код должен появиться в репозитории!

---

## Вариант 2: Через встроенный Git UI в Windsurf

Windsurf (как и VS Code) имеет встроенный Git UI.

### Шаг 1: Открыть Source Control

**Способ 1:** Боковая панель
```
Нажмите иконку с веточкой (Git) на левой панели
```

**Способ 2:** Горячая клавиша
```
Ctrl+Shift+G (Cmd+Shift+G на Mac)
```

---

### Шаг 2: Initialize Repository

Если Git еще не инициализирован:

1. В панели Source Control нажмите **Initialize Repository**
2. Выберите корневую папку проекта

---

### Шаг 3: Stage Changes

1. Наведите курсор на "Changes"
2. Нажмите **+** (плюс) рядом с "Changes" — это добавит все файлы
3. Или нажимайте **+** рядом с каждым файлом отдельно

---

### Шаг 4: Commit

1. В поле "Message" наверху введите:
   ```
   Initial commit: Ymir Clan Hub production-ready
   ```
2. Нажмите **✓ Commit** (галочку)

---

### Шаг 5: Add Remote

1. В панели Source Control нажмите **...** (три точки) → **Remote** → **Add Remote**
2. Введите URL:
   ```
   https://github.com/YOUR_USERNAME/ymir-clan-hub.git
   ```
3. Имя: `origin`

---

### Шаг 6: Push

1. В панели Source Control нажмите **...** → **Push**
2. При первом пуше выберите **origin** и **main**

---

## Вариант 3: Через SSH (для продвинутых)

Если вы хотите избежать ввода токенов каждый раз, настройте SSH.

### Шаг 1: Генерация SSH ключа

```bash
# Генерация ключа (замените email на ваш GitHub email)
ssh-keygen -t ed25519 -C "your_email@example.com"

# Нажмите Enter 3 раза (без пароля для удобства)
```

---

### Шаг 2: Копирование публичного ключа

**macOS/Linux:**
```bash
cat ~/.ssh/id_ed25519.pub
```

**Windows (PowerShell):**
```powershell
type $HOME\.ssh\id_ed25519.pub
```

Скопируйте вывод (начинается с `ssh-ed25519 ...`).

---

### Шаг 3: Добавление ключа на GitHub

1. GitHub → https://github.com/settings/keys
2. **New SSH key**
3. Title: `Windsurf laptop`
4. Key: вставьте скопированный ключ
5. **Add SSH key**

---

### Шаг 4: Изменение remote на SSH

```bash
# Проверка текущего remote
git remote -v

# Изменение на SSH
git remote set-url origin git@github.com:YOUR_USERNAME/ymir-clan-hub.git

# Проверка
git remote -v
```

Теперь `git push` не будет запрашивать логин/пароль!

---

## Типичные проблемы и решения

### 1. "Permission denied (publickey)"

**Решение:** Используйте HTTPS вместо SSH или настройте SSH ключ.

```bash
# Смена на HTTPS
git remote set-url origin https://github.com/YOUR_USERNAME/ymir-clan-hub.git
```

---

### 2. "fatal: remote origin already exists"

**Решение:** Remote уже добавлен, можете сразу делать push.

```bash
# Проверка remote
git remote -v

# Если нужно изменить URL:
git remote set-url origin https://github.com/YOUR_USERNAME/ymir-clan-hub.git
```

---

### 3. "Updates were rejected because the tip of your current branch is behind"

**Решение:** Сначала сделайте pull.

```bash
git pull origin main --rebase
git push origin main
```

---

### 4. "Authentication failed"

**Решение:** Используйте Personal Access Token вместо пароля.

```bash
# При запросе пароля вставьте PAT:
Username: ваш_никнейм
Password: ghp_xxxxxxxxxxxxxxxxxxxx (ваш токен)
```

---

### 5. ".gitignore не работает"

**Решение:** Удалите файлы из кэша Git.

```bash
# Удалить все из отслеживания
git rm -r --cached .

# Добавить снова (учитывая .gitignore)
git add .

# Закоммитить
git commit -m "fix: apply .gitignore"
```

---

## Дальнейшие коммиты (после первого пуша)

Когда вы вносите изменения в проект:

```bash
# 1. Проверка изменений
git status

# 2. Добавление файлов
git add .

# 3. Коммит
git commit -m "feat: add new feature"

# 4. Пуш (больше не нужен флаг -u)
git push
```

---

## Полезные команды Git

```bash
# Посмотреть историю коммитов
git log --oneline

# Посмотреть изменения в файлах
git diff

# Отменить изменения в файле
git checkout -- filename.txt

# Отменить последний коммит (не потеряв изменения)
git reset --soft HEAD~1

# Посмотреть текущую ветку
git branch

# Создать новую ветку
git checkout -b feature/new-feature

# Переключиться на другую ветку
git checkout main

# Слить ветку в текущую
git merge feature/new-feature
```

---

## Рекомендации

1. **Коммитьте часто** — маленькие коммиты лучше больших
2. **Пишите понятные сообщения** — `feat: add user login` вместо `changes`
3. **Используйте ветки** — для новых фичей создавайте отдельные ветки
4. **Проверяйте статус** — перед коммитом всегда делайте `git status`
5. **Пушьте регулярно** — чтобы не потерять код при сбое

---

## Готово! 🎉

Теперь ваш проект на GitHub и готов к деплою на Railway и Vercel!

Следующий шаг: переходите к **DEPLOYMENT_CHECKLIST.md** для деплоя.
