import { Outlet } from 'react-router-dom';
import { Sidebar } from './Sidebar';
import { Header } from './Header';
import { useNotificationsSocket } from '@/hooks/useNotificationsSocket';

export function AppLayout() {
  useNotificationsSocket();

  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <div className="md:ml-[260px] flex flex-1 flex-col transition-all duration-300">
        <Header />
        <main className="flex-1 p-3 sm:p-4 md:p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
