import { PrismaClient, GlobalRole, ClanRole } from '@prisma/client';
import * as crypto from 'crypto';

const prisma = new PrismaClient();

async function hashPassword(password: string): Promise<string> {
  return crypto.createHash('sha256').update(password).digest('hex');
}

async function main() {
  console.log('Seeding minimal demo data...');

  await prisma.systemSetting.createMany({
    data: [
      { key: 'auction.anti_sniper_seconds', value: 20, group: 'auction' },
      { key: 'auction.anti_sniper_extend_seconds', value: 30, group: 'auction' },
      { key: 'auction.default_min_step', value: 1, group: 'auction' },
      { key: 'randomizer.bonus_min', value: 0.03, group: 'randomizer' },
      { key: 'randomizer.bonus_max', value: 0.05, group: 'randomizer' },
      { key: 'app.maintenance_mode', value: false, group: 'general' },
      { key: 'app.default_locale', value: '"ru"', group: 'general' },
    ],
    skipDuplicates: true,
  });

  const passwordHash = await hashPassword('demo123');

  await prisma.user.upsert({
    where: { email: 'admin@ymir.local' },
    update: {},
    create: {
      email: 'admin@ymir.local',
      passwordHash,
      globalRole: GlobalRole.PORTAL_ADMIN,
      emailVerified: true,
      profile: {
        create: {
          nickname: 'SuperAdmin',
          displayName: 'Portal Admin',
          bm: 99999,
          level: 100,
        },
      },
      dkpWallet: { create: { balance: 0, onHold: 0, totalEarned: 0 } },
    },
  });

  const leaderUser = await prisma.user.upsert({
    where: { email: 'leader@ymir.local' },
    update: {},
    create: {
      email: 'leader@ymir.local',
      passwordHash,
      globalRole: GlobalRole.USER,
      emailVerified: true,
      profile: {
        create: {
          nickname: 'Asma31337',
          displayName: 'Clan Leader',
          bm: 92000,
          level: 97,
        },
      },
      dkpWallet: { create: { balance: 8500, onHold: 0, totalEarned: 12000 } },
    },
  });

  const clan = await prisma.clan.upsert({
    where: { name: 'Gods of Ymir' },
    update: {},
    create: {
      name: 'Gods of Ymir',
      tag: 'GoY',
      description: '',
    },
  });

  await prisma.clanMembership.upsert({
    where: { userId_clanId: { userId: leaderUser.id, clanId: clan.id } },
    update: { role: ClanRole.CLAN_LEADER },
    create: { userId: leaderUser.id, clanId: clan.id, role: ClanRole.CLAN_LEADER },
  });

  console.log('Seed complete.');
  console.log('Demo accounts (password: demo123):');
  console.log('  superadmin   : admin@ymir.local');
  console.log('  clan_leader  : leader@ymir.local');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
