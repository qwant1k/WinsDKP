﻿import { ApiProperty } from '@nestjs/swagger';
import { IsIn } from 'class-validator';

export class SpinDto {
  @ApiProperty({
    description: 'Fortune Wheel bet amount in DKP',
    enum: [15, 30, 50, 100],
    example: 30,
  })
  @IsIn([15, 30, 50, 100])
  bet!: 15 | 30 | 50 | 100;
}
