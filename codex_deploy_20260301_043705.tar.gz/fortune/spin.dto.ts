import { IsIn } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class SpinDto {
  @ApiProperty({
    description: 'Ставка в DKP',
    enum: [15, 30, 50, 100],
    example: 50,
  })
  @IsIn([15, 30, 50, 100])
  bet: 15 | 30 | 50 | 100;
}
